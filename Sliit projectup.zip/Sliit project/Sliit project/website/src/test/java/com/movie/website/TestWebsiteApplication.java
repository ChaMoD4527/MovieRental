package com.movie.website;

import org.springframework.boot.SpringApplication;

public class TestWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.from(WebsiteApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
