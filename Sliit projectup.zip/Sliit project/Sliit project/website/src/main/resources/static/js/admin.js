// Wait for the DOM to be fully loaded
document.addEventListener("DOMContentLoaded", () => {
  try {
    // Movie search functionality
    const movieSearch = document.getElementById("movie-search")
    const categoryFilter = document.getElementById("category-filter")
    const moviesTable = document.getElementById("movies-table")

    if (movieSearch && moviesTable) {
      movieSearch.addEventListener("keyup", filterMovies)
    }

    if (categoryFilter && moviesTable) {
      categoryFilter.addEventListener("change", filterMovies)
    }

    function filterMovies() {
      try {
        const searchTerm = movieSearch ? movieSearch.value.toLowerCase() : ""
        const category = categoryFilter ? categoryFilter.value.toLowerCase() : ""
        const rows = moviesTable.querySelectorAll("tbody tr")

        rows.forEach((row) => {
          const titleCell = row.querySelector("td:nth-child(2)")
          const categoryCell = row.querySelector("td:nth-child(3)")

          if (!titleCell || !categoryCell) return

          const title = titleCell.textContent.toLowerCase()
          const movieCategory = categoryCell.textContent.toLowerCase()

          const matchesSearch = title.includes(searchTerm)
          const matchesCategory = category === "" || movieCategory === category

          if (matchesSearch && matchesCategory) {
            row.style.display = ""
          } else {
            row.style.display = "none"
          }
        })
      } catch (error) {
        console.error("Error filtering movies:", error)
      }
    }

    // User search functionality
    const userSearch = document.getElementById("user-search")
    const subscriptionFilter = document.getElementById("subscription-filter")
    const usersTable = document.getElementById("users-table")

    if (userSearch && usersTable) {
      userSearch.addEventListener("keyup", filterUsers)
    }

    if (subscriptionFilter && usersTable) {
      subscriptionFilter.addEventListener("change", filterUsers)
    }

    function filterUsers() {
      try {
        const searchTerm = userSearch ? userSearch.value.toLowerCase() : ""
        const subscription = subscriptionFilter ? subscriptionFilter.value : ""
        const rows = usersTable.querySelectorAll("tbody tr")

        rows.forEach((row) => {
          const usernameCell = row.querySelector("td:nth-child(1)")
          const emailCell = row.querySelector("td:nth-child(2)")
          const subscriptionCell = row.querySelector("td:nth-child(3) .badge")

          if (!usernameCell || !emailCell || !subscriptionCell) return

          const username = usernameCell.textContent.toLowerCase()
          const email = emailCell.textContent.toLowerCase()
          const isSubscribed = subscriptionCell.textContent === "Subscribed"

          const matchesSearch = username.includes(searchTerm) || email.includes(searchTerm)
          const matchesSubscription =
            subscription === "" ||
            (subscription === "subscribed" && isSubscribed) ||
            (subscription === "unsubscribed" && !isSubscribed)

          if (matchesSearch && matchesSubscription) {
            row.style.display = ""
          } else {
            row.style.display = "none"
          }
        })
      } catch (error) {
        console.error("Error filtering users:", error)
      }
    }

    // Delete movie functionality
    const deleteButtons = document.querySelectorAll(".delete-btn")
    const deleteModal = document.getElementById("delete-modal")
    const confirmDelete = document.getElementById("confirm-delete")
    const cancelDelete = document.getElementById("cancel-delete")
    let movieIdToDelete = null

    if (deleteButtons.length > 0 && deleteModal) {
      deleteButtons.forEach((button) => {
        button.addEventListener("click", function () {
          movieIdToDelete = this.getAttribute("data-id")
          if (movieIdToDelete) {
            deleteModal.style.display = "block"
          }
        })
      })

      if (cancelDelete) {
        cancelDelete.addEventListener("click", () => {
          deleteModal.style.display = "none"
          movieIdToDelete = null
        })
      }

      if (confirmDelete) {
        confirmDelete.addEventListener("click", () => {
          if (movieIdToDelete) {
            try {
              // Create a form to submit the delete request
              const form = document.createElement("form")
              form.method = "POST"
              form.action = `/admin/movies/delete/${movieIdToDelete}`
              document.body.appendChild(form)
              form.submit()
            } catch (error) {
              console.error("Error deleting movie:", error)
              alert("An error occurred while deleting the movie. Please try again.")
              deleteModal.style.display = "none"
            }
          }
        })
      }

      // Close modal when clicking outside
      window.addEventListener("click", (event) => {
        if (event.target === deleteModal) {
          deleteModal.style.display = "none"
          movieIdToDelete = null
        }
      })
    }

    // Image preview for add/edit movie
    const imageUrlInput = document.getElementById("imageUrl")
    const imagePreview = document.getElementById("image-preview")

    if (imageUrlInput && imagePreview) {
      imageUrlInput.addEventListener("blur", function () {
        try {
          const url = this.value
          if (url && url.trim() !== "") {
            imagePreview.src = url
            imagePreview.style.display = "block"
          } else {
            imagePreview.style.display = "none"
          }
        } catch (error) {
          console.error("Error updating image preview:", error)
        }
      })

      // Initial preview if URL exists
      if (imageUrlInput.value && imageUrlInput.value.trim() !== "") {
        imagePreview.src = imageUrlInput.value
        imagePreview.style.display = "block"
      }
    }

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll(".alert")
    if (alerts.length > 0) {
      setTimeout(() => {
        alerts.forEach((alert) => {
          alert.style.opacity = "0"
          setTimeout(() => {
            alert.style.display = "none"
          }, 500)
        })
      }, 5000)
    }
  } catch (error) {
    console.error("Error initializing admin scripts:", error)
  }
})
