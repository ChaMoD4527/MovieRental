// Wait for the DOM to be fully loaded
document.addEventListener("DOMContentLoaded", () => {
  // Mobile menu toggle
  const menuToggle = document.querySelector(".mobile-menu-toggle")
  const nav = document.querySelector("nav")

  if (menuToggle && nav) {
    menuToggle.addEventListener("click", () => {
      nav.classList.toggle("show")

      // Accessibility - toggle aria-expanded
      const expanded = nav.classList.contains("show")
      menuToggle.setAttribute("aria-expanded", expanded)
    })
  }

  // Star rating functionality
  const starRating = document.querySelector(".star-rating")
  if (starRating) {
    const stars = starRating.querySelectorAll("input")
    const ratingValue = document.getElementById("rating-value")

    stars.forEach((star) => {
      star.addEventListener("change", function () {
        if (ratingValue) {
          ratingValue.textContent = this.value
        }
      })
    })
  }

  // Movie search functionality
  const searchInput = document.getElementById("search-input")
  const movieCards = document.querySelectorAll(".movie-card")

  if (searchInput && movieCards.length > 0) {
    searchInput.addEventListener("keyup", function () {
      const searchTerm = this.value.toLowerCase()

      movieCards.forEach((card) => {
        const title = card.querySelector("h3")?.textContent.toLowerCase() || ""
        const description = card.querySelector("p")?.textContent.toLowerCase() || ""

        if (title.includes(searchTerm) || description.includes(searchTerm)) {
          card.style.display = "block"
        } else {
          card.style.display = "none"
        }
      })
    })
  }

  // Payment form validation
  const paymentForm = document.querySelector(".payment-form")

  if (paymentForm) {
    paymentForm.addEventListener("submit", (e) => {
      const cardNumber = document.getElementById("cardNumber")?.value || ""
      const cardName = document.getElementById("cardName")?.value || ""
      const expiryDate = document.getElementById("expiryDate")?.value || ""
      const cvv = document.getElementById("cvv")?.value || ""

      let isValid = true

      // Simple validation
      if (cardNumber.length < 16) {
        alert("Please enter a valid card number")
        isValid = false
      }

      if (cardName.trim() === "") {
        alert("Please enter the name on card")
        isValid = false
      }

      if (expiryDate.trim() === "") {
        alert("Please enter the expiry date")
        isValid = false
      }

      if (cvv.length < 3) {
        alert("Please enter a valid CVV")
        isValid = false
      }

      if (!isValid) {
        e.preventDefault()
      }
    })
  }

  // Function to format time
  function formatTime(seconds) {
    if (!seconds || isNaN(seconds)) return "0:00"

    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = Math.floor(seconds % 60)
    return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`
  }

  // Update progress display on continue watching page
  const progressBars = document.querySelectorAll(".movie-progress")

  progressBars.forEach((bar) => {
    const movieId = bar.getAttribute("data-movie-id")
    if (!movieId) return

    const savedTime = localStorage.getItem(`movie_progress_${movieId}`)

    if (savedTime && !isNaN(savedTime)) {
      // Set width based on progress (assuming average movie length of 2 hours)
      const progress = Math.min((Number.parseFloat(savedTime) / (2 * 60 * 60)) * 100, 100)
      bar.style.width = progress + "%"

      // Add tooltip with time
      bar.setAttribute("title", `Resume at ${formatTime(Number.parseFloat(savedTime))}`)
    } else {
      bar.style.width = "0%"
    }
  })

  // Handle image loading errors
  const images = document.querySelectorAll("img")
  images.forEach((img) => {
    img.addEventListener("error", function () {
      this.src = "/images/placeholder.jpg"
      this.alt = "Image not available"
    })
  })

  // Video player functionality
  const videoPlayer = document.getElementById("movie-player")
  if (videoPlayer) {
    // Save video progress
    videoPlayer.addEventListener("timeupdate", function () {
      try {
        const movieId =
          new URLSearchParams(window.location.search).get("id") || window.location.pathname.split("/").pop()

        if (movieId) {
          localStorage.setItem(`movie_progress_${movieId}`, this.currentTime.toString())
        }
      } catch (error) {
        console.error("Error saving video progress:", error)
      }
    })

    // Load saved progress
    try {
      const movieId = new URLSearchParams(window.location.search).get("id") || window.location.pathname.split("/").pop()

      if (movieId) {
        const savedTime = localStorage.getItem(`movie_progress_${movieId}`)

        if (savedTime && !isNaN(savedTime)) {
          videoPlayer.currentTime = Number.parseFloat(savedTime)
        }
      }
    } catch (error) {
      console.error("Error loading saved progress:", error)
    }

    // Add to watch history when video starts playing
    videoPlayer.addEventListener("play", () => {
      try {
        const movieId =
          new URLSearchParams(window.location.search).get("id") || window.location.pathname.split("/").pop()

        if (movieId) {
          // Get existing watch history or initialize empty array
          let watchHistory = []
          try {
            const storedHistory = localStorage.getItem("watch_history")
            watchHistory = storedHistory ? JSON.parse(storedHistory) : []
          } catch (e) {
            console.error("Error parsing watch history:", e)
            watchHistory = []
          }

          // Add movie to history if not already there
          if (!watchHistory.includes(movieId)) {
            watchHistory.unshift(movieId) // Add to beginning

            // Keep only the last 10 movies
            if (watchHistory.length > 10) {
              watchHistory = watchHistory.slice(0, 10)
            }

            localStorage.setItem("watch_history", JSON.stringify(watchHistory))
          }
        }
      } catch (error) {
        console.error("Error updating watch history:", error)
      }
    })
  }

  // Auto-hide alerts after 5 seconds
  const alerts = document.querySelectorAll(".alert")
  if (alerts.length > 0) {
    setTimeout(() => {
      alerts.forEach((alert) => {
        alert.style.opacity = "0"
        setTimeout(() => {
          alert.style.display = "none"
        }, 500)
      })
    }, 5000)
  }
})
