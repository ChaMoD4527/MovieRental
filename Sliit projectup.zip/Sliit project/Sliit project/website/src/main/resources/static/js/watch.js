// Wait for the DOM to be fully loaded
document.addEventListener("DOMContentLoaded", () => {
  const videoPlayer = document.getElementById("movie-player")

  if (videoPlayer) {
    try {
      // Save video progress
      videoPlayer.addEventListener("timeupdate", function () {
        try {
          const movieId =
            new URLSearchParams(window.location.search).get("id") || window.location.pathname.split("/").pop()

          if (movieId) {
            localStorage.setItem(`movie_progress_${movieId}`, this.currentTime.toString())
          }
        } catch (error) {
          console.error("Error saving video progress:", error)
        }
      })

      // Load saved progress
      try {
        const movieId =
          new URLSearchParams(window.location.search).get("id") || window.location.pathname.split("/").pop()

        if (movieId) {
          const savedTime = localStorage.getItem(`movie_progress_${movieId}`)

          if (savedTime && !isNaN(savedTime)) {
            videoPlayer.currentTime = Number.parseFloat(savedTime)
          }
        }
      } catch (error) {
        console.error("Error loading saved progress:", error)
      }

      // Add to watch history when video starts playing
      videoPlayer.addEventListener("play", () => {
        try {
          const movieId =
            new URLSearchParams(window.location.search).get("id") || window.location.pathname.split("/").pop()

          if (movieId) {
            // Get existing watch history or initialize empty array
            let watchHistory = []
            try {
              const storedHistory = localStorage.getItem("watch_history")
              watchHistory = storedHistory ? JSON.parse(storedHistory) : []
            } catch (e) {
              console.error("Error parsing watch history:", e)
              watchHistory = []
            }

            // Add movie to history if not already there
            if (!watchHistory.includes(movieId)) {
              watchHistory.unshift(movieId) // Add to beginning

              // Keep only the last 10 movies
              if (watchHistory.length > 10) {
                watchHistory = watchHistory.slice(0, 10)
              }

              localStorage.setItem("watch_history", JSON.stringify(watchHistory))
            }
          }
        } catch (error) {
          console.error("Error updating watch history:", error)
        }
      })
    } catch (error) {
      console.error("Error initializing video player:", error)
    }
  }

  // Handle fullscreen toggle
  const fullscreenButton = document.getElementById("fullscreen-toggle")

  if (fullscreenButton && videoPlayer) {
    fullscreenButton.addEventListener("click", () => {
      try {
        if (document.fullscreenElement) {
          document.exitFullscreen()
        } else {
          videoPlayer.requestFullscreen()
        }
      } catch (error) {
        console.error("Error toggling fullscreen:", error)
      }
    })
  }

  // Auto-hide controls
  const videoControls = document.querySelector(".video-controls")
  let controlsTimeout

  if (videoPlayer && videoControls) {
    try {
      videoPlayer.addEventListener("mousemove", () => {
        videoControls.style.opacity = "1"

        clearTimeout(controlsTimeout)

        controlsTimeout = setTimeout(() => {
          if (!videoPlayer.paused) {
            videoControls.style.opacity = "0"
          }
        }, 3000)
      })

      videoPlayer.addEventListener("pause", () => {
        videoControls.style.opacity = "1"
      })

      videoPlayer.addEventListener("play", () => {
        controlsTimeout = setTimeout(() => {
          videoControls.style.opacity = "0"
        }, 3000)
      })
    } catch (error) {
      console.error("Error setting up video controls:", error)
    }
  }

  // Format time display
  function formatTime(seconds) {
    if (!seconds || isNaN(seconds)) return "0:00"

    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = Math.floor(seconds % 60)
    return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`
  }

  // Update time display
  const currentTimeDisplay = document.getElementById("current-time")
  const durationDisplay = document.getElementById("duration")

  if (videoPlayer && currentTimeDisplay && durationDisplay) {
    try {
      videoPlayer.addEventListener("loadedmetadata", () => {
        durationDisplay.textContent = formatTime(videoPlayer.duration)
      })

      videoPlayer.addEventListener("timeupdate", () => {
        currentTimeDisplay.textContent = formatTime(videoPlayer.currentTime)
      })
    } catch (error) {
      console.error("Error updating time display:", error)
    }
  }
})
