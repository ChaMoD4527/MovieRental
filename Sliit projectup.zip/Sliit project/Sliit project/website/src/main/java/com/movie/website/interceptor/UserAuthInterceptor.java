package com.movie.website.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.jetbrains.annotations.NotNull;
import org.springframework.web.servlet.HandlerInterceptor;

import com.movie.website.model.User;
import java.util.logging.Logger;

public class UserAuthInterceptor implements HandlerInterceptor {
    private static final Logger logger = Logger.getLogger(UserAuthInterceptor.class.getName());

    @Override
    public boolean preHandle(@NotNull HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            // Redirect to login page if user is not logged in
            logger.info("Unauthorized access attempt to: " + request.getRequestURI());
            response.sendRedirect("/login");
            return false;
        }

        logger.info("Authorized access by user: " + user.getUsername() + " to: " + request.getRequestURI());
        return true;
    }
}