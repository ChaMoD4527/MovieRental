package com.movie.website.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.movie.website.interceptor.AdminAuthInterceptor;
import com.movie.website.interceptor.UserAuthInterceptor;

@Configuration
public class SecurityConfig {

    @Bean
    @Primary
    public UserAuthInterceptor userAuthInterceptor() {
        return new UserAuthInterceptor();
    }

    @Bean
    @Primary
    public AdminAuthInterceptor adminAuthInterceptor() {
        return new AdminAuthInterceptor();
    }
}