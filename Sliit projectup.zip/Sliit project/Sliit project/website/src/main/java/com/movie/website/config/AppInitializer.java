package com.movie.website.config;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.SessionCookieConfig;
import jakarta.servlet.SessionTrackingMode;

import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;
import java.util.logging.Logger;
import java.util.logging.Level;

@Configuration
public class AppInitializer {
    private static final Logger logger = Logger.getLogger(AppInitializer.class.getName());

    @Bean
    public ServletContextInitializer initializer() {
        return new ServletContextInitializer() {
            @Override
            public void onStartup(ServletContext servletContext) throws ServletException {
                try {
                    // Set servlet context parameters
                    servletContext.setInitParameter("spring.profiles.active", "default");
                    servletContext.setInitParameter("defaultHtmlEscape", "true");

                    // Configure session tracking
                    servletContext.setSessionTrackingModes(
                            Collections.singleton(SessionTrackingMode.COOKIE)
                    );

                    // Configure session cookie
                    SessionCookieConfig sessionCookieConfig = servletContext.getSessionCookieConfig();
                    sessionCookieConfig.setHttpOnly(true);
                    sessionCookieConfig.setName("MOVIEHUB_SESSION");
                    // Set session timeout in seconds (30 minutes = 1800 seconds)
                    sessionCookieConfig.setMaxAge(1800);

                    logger.info("ServletContext initialized successfully");
                } catch (Exception e) {
                    logger.log(Level.SEVERE, "Error initializing ServletContext", e);
                    throw new ServletException("Error initializing ServletContext", e);
                }
            }
        };
    }
}