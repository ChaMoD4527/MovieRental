package com.movie.website.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.jetbrains.annotations.NotNull;
import org.springframework.web.servlet.HandlerInterceptor;

import com.movie.website.model.User;
import java.util.logging.Logger;

public class AdminAuthInterceptor implements HandlerInterceptor {
    private static final Logger logger = Logger.getLogger(AdminAuthInterceptor.class.getName());

    @Override
    public boolean preHandle(@NotNull HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null || !user.isAdmin()) {
            // Redirect to login page if user is not an admin
            logger.warning("Unauthorized admin access attempt to: " + request.getRequestURI() +
                    (user != null ? " by user: " + user.getUsername() : " by unauthenticated user"));
            response.sendRedirect("/login");
            return false;
        }

        logger.info("Authorized admin access by: " + user.getUsername() + " to: " + request.getRequestURI());
        return true;
    }
}