package com.movieapp.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Rental implements Serializable {
    private String rentalId;
    private String userId;
    private String movieId;
    private LocalDateTime rentalDate;
    private LocalDateTime expiryDate;
    private boolean isActive;

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    public Rental() {
    }

    public Rental(String rentalId, String userId, String movieId, 
                 LocalDateTime rentalDate, LocalDateTime expiryDate, boolean isActive) {
        this.rentalId = rentalId;
        this.userId = userId;
        this.movieId = movieId;
        this.rentalDate = rentalDate;
        this.expiryDate = expiryDate;
        this.isActive = isActive;
    }

    // Getters and setters
    public String getRentalId() {
        return rentalId;
    }

    public void setRentalId(String rentalId) {
        this.rentalId = rentalId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public LocalDateTime getRentalDate() {
        return rentalDate;
    }

    public void setRentalDate(LocalDateTime rentalDate) {
        this.rentalDate = rentalDate;
    }

    public LocalDateTime getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDateTime expiryDate) {
        this.expiryDate = expiryDate;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    // For file storage - convert to CSV format
    public String toCsvString() {
        return rentalId + "," + userId + "," + movieId + "," + 
               rentalDate.format(DATE_FORMATTER) + "," + 
               expiryDate.format(DATE_FORMATTER) + "," + isActive;
    }

    // For file storage - parse from CSV format
    public static Rental fromCsvString(String csvLine) {
        String[] parts = csvLine.split(",");
        if (parts.length != 6) {
            throw new IllegalArgumentException("Invalid CSV format for Rental");
        }
        
        return new Rental(
            parts[0], // rentalId
            parts[1], // userId
            parts[2], // movieId
            LocalDateTime.parse(parts[3], DATE_FORMATTER), // rentalDate
            LocalDateTime.parse(parts[4], DATE_FORMATTER), // expiryDate
            Boolean.parseBoolean(parts[5]) // isActive
        );
    }

    // Check if rental is expired
    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expiryDate);
    }
}