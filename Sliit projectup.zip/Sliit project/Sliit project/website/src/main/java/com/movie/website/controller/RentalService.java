package com.movie.website.service;

import com.movie.website.model.Rental;
import com.movie.website.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class RentalService {

    private static final String DATA_DIR = "data";
    private static final String RENTALS_FILE = DATA_DIR + "/rentals.dat";
    private List<Rental> rentals;

    @Autowired
    private SubscriptionService subscriptionService;

    @PostConstruct
    public void init() {
        FileUtil.ensureDirectoryExists(DATA_DIR);
        this.rentals = FileUtil.readFromFile(RENTALS_FILE);
    }

    public List<Rental> getAllRentals() {
        return rentals;
    }

    public List<Rental> getRentalsByUserId(String userId) {
        return rentals.stream()
                .filter(rental -> rental.getUserId().equals(userId))
                .collect(Collectors.toList());
    }

    public Rental getRentalById(String id) {
        return rentals.stream()
                .filter(rental -> rental.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public List<Rental> getActiveRentalsByUserId(String userId) {
        LocalDate today = LocalDate.now();
        return rentals.stream()
                .filter(rental -> rental.getUserId().equals(userId) && 
                                 rental.getReturnDate().isAfter(today))
                .collect(Collectors.toList());
    }

    public Rental rentMovie(String userId, String movieId, double rentalCost, int rentalDays) {
        // Check if user has an active subscription (for potential discount)
        boolean hasActiveSubscription = subscriptionService.hasActiveSubscription(userId);
        
        // Apply discount if user has active subscription
        if (hasActiveSubscription) {
            rentalCost = rentalCost * 0.8; // 20% discount for subscribers
        }

        LocalDate rentalDate = LocalDate.now();
        LocalDate returnDate = rentalDate.plusDays(rentalDays);

        Rental rental = new Rental(
                UUID.randomUUID().toString(),
                userId,
                movieId,
                rentalDate,
                returnDate,
                rentalCost
        );

        rentals.add(rental);
        saveRentals();
        return rental;
    }

    public void extendRental(String rentalId, int additionalDays, double additionalCost) {
        rentals = rentals.stream()
                .map(rental -> {
                    if (rental.getId().equals(rentalId)) {
                        rental.setReturnDate(rental.getReturnDate().plusDays(additionalDays));
                        rental.setRentalCost(rental.getRentalCost() + additionalCost);
                    }
                    return rental;
                })
                .collect(Collectors.toList());
        saveRentals();
    }

    public void returnMovie(String rentalId) {
        rentals = rentals.stream()
                .map(rental -> {
                    if (rental.getId().equals(rentalId)) {
                        rental.setReturnDate(LocalDate.now());
                    }
                    return rental;
                })
                .collect(Collectors.toList());
        saveRentals();
    }

    private void saveRentals() {
        FileUtil.writeToFile(rentals, RENTALS_FILE);
    }
}