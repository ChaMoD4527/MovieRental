package com.movieapp.servlet;

import com.movieapp.model.CardDetails;
import com.movieapp.model.Rental;
import com.movieapp.service.CardService;
import com.movieapp.service.RentalService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/rent/*")
public class RentalServlet extends HttpServlet {
    private final RentalService rentalService = new RentalService();
    private final CardService cardService = new CardService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String movieId = request.getParameter("movieId");
        if (movieId == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Movie ID is required");
            return;
        }
        
        // Check if the user already has an active rental for this movie
        if (rentalService.hasActiveRental(userId, movieId)) {
            response.sendRedirect(request.getContextPath() + "/watch?movieId=" + movieId);
            return;
        }
        
        // Get user's cards for the rental form
        request.setAttribute("cards", cardService.getCardsByUserId(userId));
        request.setAttribute("defaultCard", cardService.getDefaultCard(userId));
        request.setAttribute("movieId", movieId);
        
        request.getRequestDispatcher("/WEB-INF/views/rental-form.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String movieId = request.getParameter("movieId");
        if (movieId == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Movie ID is required");
            return;
        }
        
        String useDefaultCard = request.getParameter("useDefaultCard");
        
        // If using default card, check if one exists
        if ("on".equals(useDefaultCard)) {
            CardDetails defaultCard = cardService.getDefaultCard(userId);
            if (defaultCard == null) {
                request.setAttribute("error", "No default card found. Please add a card.");
                doGet(request, response);
                return;
            }
        } else {
            // Process new card details
            String cardNumber = request.getParameter("cardNumber");
            String cardholderName = request.getParameter("cardholderName");
            String expiryMonth = request.getParameter("expiryMonth");
            String expiryYear = request.getParameter("expiryYear");
            String cvc = request.getParameter("cvc");
            boolean saveCard = "on".equals(request.getParameter("saveCard"));
            boolean setAsDefault = "on".equals(request.getParameter("setAsDefault"));
            
            // Validate card details
            if (cardNumber == null || cardNumber.trim().isEmpty() ||
                cardholderName == null || cardholderName.trim().isEmpty() ||
                expiryMonth == null || expiryMonth.trim().isEmpty() ||
                expiryYear == null || expiryYear.trim().isEmpty() ||
                cvc == null || cvc.trim().isEmpty()) {
                
                request.setAttribute("error", "All card details are required");
                doGet(request, response);
                return;
            }
            
            // Save card if requested
            if (saveCard) {
                CardDetails card = new CardDetails(userId, cardNumber, cardholderName, 
                                                  expiryMonth, expiryYear, cvc, setAsDefault);
                cardService.addCard(card);
            }
        }
        
        // Process the rental
        Rental rental = rentalService.rentMovie(userId, movieId);
        
        // Redirect to watch page
        response.sendRedirect(request.getContextPath() + "/watch?movieId=" + movieId);
    }
}