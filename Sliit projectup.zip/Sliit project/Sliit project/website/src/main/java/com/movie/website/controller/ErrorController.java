package com.movie.website.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import jakarta.servlet.http.HttpServletRequest;
import java.util.logging.Logger;

@Controller
@RequestMapping("/error")
public class ErrorController implements org.springframework.boot.web.servlet.error.ErrorController {
    private static final Logger logger = Logger.getLogger(ErrorController.class.getName());

    @GetMapping("/404")
    public String notFound(HttpServletRequest request, Model model) {
        logger.warning("404 error page accessed for path: " + request.getAttribute("jakarta.servlet.forward.request_uri"));
        model.addAttribute("path", request.getAttribute("jakarta.servlet.forward.request_uri"));
        return "error/404";
    }

    @GetMapping("/500")
    public String serverError(HttpServletRequest request, Model model) {
        logger.severe("500 error page accessed for path: " + request.getAttribute("jakarta.servlet.forward.request_uri"));
        model.addAttribute("path", request.getAttribute("jakarta.servlet.forward.request_uri"));
        model.addAttribute("exception", request.getAttribute("jakarta.servlet.error.exception"));
        return "error/500";
    }

    @GetMapping("/general")
    public String generalError(HttpServletRequest request, Model model) {
        logger.warning("General error page accessed for path: " + request.getAttribute("jakarta.servlet.forward.request_uri"));
        model.addAttribute("path", request.getAttribute("jakarta.servlet.forward.request_uri"));
        model.addAttribute("exception", request.getAttribute("jakarta.servlet.error.exception"));
        return "error/general";
    }
}