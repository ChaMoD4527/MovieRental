package com.movie.website;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main application class for the Movie Website
 *
 * Note: @SpringBootApplication already includes:
 * - @Configuration
 * - @EnableAutoConfiguration
 * - @ComponentScan (for the current package and sub-packages)
 */
@SpringBootApplication
@EnableScheduling
public class WebsiteApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebsiteApplication.class, args);
    }
}