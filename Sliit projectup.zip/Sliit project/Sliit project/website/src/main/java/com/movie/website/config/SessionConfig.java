package com.movie.website.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;

@Configuration
public class SessionConfig {

    @Bean
    public CookieSerializer cookieSerializer() {
        DefaultCookieSerializer serializer = new DefaultCookieSerializer();
        serializer.setCookieName("MOVIEHUB_SESSION");
        serializer.setCookieMaxAge(3600); // 1 hour
        serializer.setCookiePath("/");
        serializer.setUseSecureCookie(false); // Set to true in production with HTTPS
        return serializer;
    }
}