package com.movie.website.controller;

import com.movie.website.data.DataStore;
import com.movie.website.model.Movie;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HomeController {
    
    private final DataStore dataStore = DataStore.getInstance();
    
    @GetMapping("/")
    public String home(Model model) {
        List<Movie> newArrivals = dataStore.getNewArrivals();
        List<Movie> topRated = dataStore.getTopRatedMovies();
        List<Movie> tvSeries = dataStore.getTvSeries();
        
        model.addAttribute("newArrivals", newArrivals);
        model.addAttribute("topRated", topRated);
        model.addAttribute("tvSeries", tvSeries);
        
        return "home";
    }
    
    @GetMapping("/about")
    public String about() {
        return "about";
    }
}
