package com.movie.website.config;

import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.movie.website.interceptor.AdminAuthInterceptor;
import com.movie.website.interceptor.UserAuthInterceptor;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Autowired
    private UserAuthInterceptor userAuthInterceptor;

    @Autowired
    private AdminAuthInterceptor adminAuthInterceptor;

    @Override
    public void addInterceptors(@NotNull InterceptorRegistry registry) {
        // Register user authentication interceptor
        registry.addInterceptor(userAuthInterceptor)
                .addPathPatterns("/profile/**", "/movies/**", "/watch/**", "/subscription/**", "/payment/**")
                .excludePathPatterns("/login", "/register", "/about", "/", "/css/**", "/js/**", "/images/**");

        // Register admin authentication interceptor
        registry.addInterceptor(adminAuthInterceptor)
                .addPathPatterns("/admin/**");
    }
}