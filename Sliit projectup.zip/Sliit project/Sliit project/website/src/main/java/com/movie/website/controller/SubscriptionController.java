package com.movie.website.controller;

import com.movie.website.model.Subscription;
import com.movie.website.model.SubscriptionPlan;
import com.movie.website.service.SubscriptionPlanService;
import com.movie.website.service.SubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/subscriptions")
public class SubscriptionController {

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private SubscriptionPlanService subscriptionPlanService;

    @GetMapping
    public String getAllSubscriptionPlans(Model model) {
        List<SubscriptionPlan> plans = subscriptionPlanService.getAllSubscriptionPlans();
        model.addAttribute("plans", plans);
        return "subscription/plans";
    }

    @GetMapping("/my-subscription")
    public String getMySubscription(@RequestParam String userId, Model model) {
        Subscription activeSubscription = subscriptionService.getActiveSubscriptionForUser(userId);
        if (activeSubscription != null) {
            SubscriptionPlan plan = subscriptionPlanService.getSubscriptionPlanById(activeSubscription.getSubscriptionPlanId());
            model.addAttribute("subscription", activeSubscription);
            model.addAttribute("plan", plan);
        }
        return "subscription/my-subscription";
    }

    @GetMapping("/subscribe")
    public String showSubscribeForm(@RequestParam String userId, @RequestParam String planId, Model model) {
        SubscriptionPlan plan = subscriptionPlanService.getSubscriptionPlanById(planId);
        model.addAttribute("plan", plan);
        model.addAttribute("userId", userId);
        return "subscription/subscribe";
    }

    @PostMapping("/subscribe")
    public String subscribe(@RequestParam String userId, @RequestParam String planId) {
        subscriptionService.createSubscription(userId, planId);
        return "redirect:/subscriptions/my-subscription?userId=" + userId;
    }

    @PostMapping("/cancel")
    public String cancelSubscription(@RequestParam String subscriptionId, @RequestParam String userId) {
        subscriptionService.cancelSubscription(subscriptionId);
        return "redirect:/subscriptions/my-subscription?userId=" + userId;
    }

    // Admin endpoints
    @GetMapping("/admin/plans")
    public String manageSubscriptionPlans(Model model) {
        List<SubscriptionPlan> plans = subscriptionPlanService.getAllSubscriptionPlans();
        model.addAttribute("plans", plans);
        return "admin/subscription-plans";
    }

    @GetMapping("/admin/plans/add")
    public String showAddPlanForm(Model model) {
        model.addAttribute("plan", new SubscriptionPlan());
        return "admin/add-plan";
    }

    @PostMapping("/admin/plans/add")
    public String addPlan(@ModelAttribute SubscriptionPlan plan) {
        subscriptionPlanService.addSubscriptionPlan(plan);
        return "redirect:/subscriptions/admin/plans";
    }

    @GetMapping("/admin/plans/edit/{id}")
    public String showEditPlanForm(@PathVariable String id, Model model) {
        SubscriptionPlan plan = subscriptionPlanService.getSubscriptionPlanById(id);
        model.addAttribute("plan", plan);
        return "admin/edit-plan";
    }

    @PostMapping("/admin/plans/edit")
    public String editPlan(@ModelAttribute SubscriptionPlan plan) {
        subscriptionPlanService.updateSubscriptionPlan(plan);
        return "redirect:/subscriptions/admin/plans";
    }

    @PostMapping("/admin/plans/delete")
    public String deletePlan(@RequestParam String id) {
        subscriptionPlanService.deleteSubscriptionPlan(id);
        return "redirect:/subscriptions/admin/plans";
    }
}