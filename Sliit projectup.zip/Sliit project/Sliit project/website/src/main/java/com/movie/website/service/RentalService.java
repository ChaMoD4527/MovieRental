package com.movieapp.service;

import com.movieapp.model.Rental;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class RentalService {
    private static final String RENTAL_FILE = "rentals.txt";
    private final FileStorageService fileStorageService;
    
    public RentalService() {
        this.fileStorageService = new FileStorageService();
    }
    
    // Rent a movie
    public Rental rentMovie(String userId, String movieId) throws IOException {
        // Create a new rental with 48 hours expiry
        String rentalId = UUID.randomUUID().toString();
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expiry = now.plusHours(48); // 48-hour rental period
        
        Rental rental = new Rental(rentalId, userId, movieId, now, expiry, true);
        fileStorageService.appendLineToFile(RENTAL_FILE, rental.toCsvString());
        
        return rental;
    }
    
    // Get all rentals for a user
    public List<Rental> getRentalsByUserId(String userId) throws IOException {
        List<String> lines = fileStorageService.readLinesFromFile(RENTAL_FILE);
        return lines.stream()
                .map(Rental::fromCsvString)
                .filter(rental -> rental.getUserId().equals(userId))
                .collect(Collectors.toList());
    }
    
    // Get all active rentals for a user
    public List<Rental> getActiveRentalsByUserId(String userId) throws IOException {
        LocalDateTime now = LocalDateTime.now();
        return getRentalsByUserId(userId).stream()
                .filter(rental -> rental.isActive() && !rental.isExpired())
                .collect(Collectors.toList());
    }
    
    // Check if a user has an active rental for a movie
    public boolean hasActiveRental(String userId, String movieId) throws IOException {
        return getActiveRentalsByUserId(userId).stream()
                .anyMatch(rental -> rental.getMovieId().equals(movieId));
    }
    
    // Get all rentals (for admin)
    public List<Rental> getAllRentals() throws IOException {
        List<String> lines = fileStorageService.readLinesFromFile(RENTAL_FILE);
        return lines.stream()
                .map(Rental::fromCsvString)
                .collect(Collectors.toList());
    }
}