package com.movieapp.servlet;

import com.movieapp.model.Rental;
import com.movieapp.service.RentalService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/*")
public class AdminServlet extends HttpServlet {
    private final RentalService rentalService = new RentalService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");
        Boolean isAdmin = (Boolean) session.getAttribute("isAdmin");
        
        if (userId == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        if (isAdmin == null || !isAdmin) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Admin access required");
            return;
        }
        
        String path = request.getPathInfo();
        
        if (path == null || path.equals("/")) {
            // Admin dashboard
            request.getRequestDispatcher("/WEB-INF/views/admin/dashboard.jsp").forward(request, response);
        } else if (path.equals("/rentals")) {
            // View all rentals
            List<Rental> rentals = rentalService.getAllRentals();
            request.setAttribute("rentals", rentals);
            request.getRequestDispatcher("/WEB-INF/views/admin/rentals.jsp").forward(request, response);
        } else if (path.equals("/user-rentals")) {
            // View rentals for a specific user
            String targetUserId = request.getParameter("userId");
            if (targetUserId == null) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "User ID is required");
                return;
            }
            
            List<Rental> userRentals = rentalService.getRentalsByUserId(targetUserId);
            request.setAttribute("userRentals", userRentals);
            request.setAttribute("targetUserId", targetUserId);
            request.getRequestDispatcher("/WEB-INF/views/admin/user-rentals.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
}