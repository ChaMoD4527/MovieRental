package com.movie.website.data;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;

public class Stack<T> implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    
    private List<T> elements;
    
    public Stack() {
        this.elements = new ArrayList<>();
    }
    
    public synchronized void push(T item) {
        if (item != null) {
            elements.add(item);
        }
    }
    
    public synchronized T pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return elements.remove(elements.size() - 1);
    }
    
    public synchronized T peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return elements.get(elements.size() - 1);
    }
    
    public synchronized boolean isEmpty() {
        return elements.isEmpty();
    }
    
    public synchronized int size() {
        return elements.size();
    }
    
    public synchronized List<T> getAllElements() {
        return new ArrayList<>(elements);
    }
    
    public synchronized boolean removeElement(T element) {
        return elements.remove(element);
    }
    
    public synchronized void clear() {
        elements.clear();
    }
}
