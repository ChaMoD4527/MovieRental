package com.movieapp.service;

import com.movieapp.model.CardDetails;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class CardService {
    private static final String CARD_DETAILS_FILE = "card_details.txt";
    private final FileStorageService fileStorageService;
    
    public CardService() {
        this.fileStorageService = new FileStorageService();
    }
    
    // Add a new card
    public void addCard(CardDetails cardDetails) throws IOException {
        // If this card is set as default, unset any existing default cards for this user
        if (cardDetails.isDefault()) {
            unsetDefaultCards(cardDetails.getUserId());
        }
        
        fileStorageService.appendLineToFile(CARD_DETAILS_FILE, cardDetails.toCsvString());
    }
    
    // Get all cards for a user
    public List<CardDetails> getCardsByUserId(String userId) throws IOException {
        List<String> lines = fileStorageService.readLinesFromFile(CARD_DETAILS_FILE);
        return lines.stream()
                .map(CardDetails::fromCsvString)
                .filter(card -> card.getUserId().equals(userId))
                .collect(Collectors.toList());
    }
    
    // Get default card for a user
    public CardDetails getDefaultCard(String userId) throws IOException {
        List<CardDetails> userCards = getCardsByUserId(userId);
        return userCards.stream()
                .filter(CardDetails::isDefault)
                .findFirst()
                .orElse(null);
    }
    
    // Set a card as default
    public void setDefaultCard(String userId, String cardNumber) throws IOException {
        List<String> lines = fileStorageService.readLinesFromFile(CARD_DETAILS_FILE);
        List<String> updatedLines = new ArrayList<>();
        
        for (String line : lines) {
            CardDetails card = CardDetails.fromCsvString(line);
            if (card.getUserId().equals(userId)) {
                // Set the specified card as default, unset others
                boolean shouldBeDefault = card.getCardNumber().equals(cardNumber);
                card.setDefault(shouldBeDefault);
                updatedLines.add(card.toCsvString());
            } else {
                updatedLines.add(line);
            }
        }
        
        fileStorageService.writeLinesToFile(CARD_DETAILS_FILE, updatedLines);
    }
    
    // Unset all default cards for a user
    private void unsetDefaultCards(String userId) throws IOException {
        List<String> lines = fileStorageService.readLinesFromFile(CARD_DETAILS_FILE);
        List<String> updatedLines = new ArrayList<>();
        
        for (String line : lines) {
            CardDetails card = CardDetails.fromCsvString(line);
            if (card.getUserId().equals(userId) && card.isDefault()) {
                card.setDefault(false);
                updatedLines.add(card.toCsvString());
            } else {
                updatedLines.add(line);
            }
        }
        
        fileStorageService.writeLinesToFile(CARD_DETAILS_FILE, updatedLines);
    }
    
    // Delete a card
    public void deleteCard(String userId, String cardNumber) throws IOException {
        List<String> lines = fileStorageService.readLinesFromFile(CARD_DETAILS_FILE);
        List<String> updatedLines = lines.stream()
                .filter(line -> {
                    CardDetails card = CardDetails.fromCsvString(line);
                    return !(card.getUserId().equals(userId) && card.getCardNumber().equals(cardNumber));
                })
                .collect(Collectors.toList());
        
        fileStorageService.writeLinesToFile(CARD_DETAILS_FILE, updatedLines);
    }
}