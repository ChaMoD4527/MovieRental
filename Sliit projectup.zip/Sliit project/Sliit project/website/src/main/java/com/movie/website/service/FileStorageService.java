package com.movieapp.service;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FileStorageService {
    private static final String DATA_DIRECTORY = "data";
    
    public FileStorageService() {
        // Create data directory if it doesn't exist
        try {
            Files.createDirectories(Paths.get(DATA_DIRECTORY));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // Write a list of lines to a file
    public void writeLinesToFile(String fileName, List<String> lines) throws IOException {
        Path filePath = Paths.get(DATA_DIRECTORY, fileName);
        Files.write(filePath, lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }
    
    // Append a line to a file
    public void appendLineToFile(String fileName, String line) throws IOException {
        Path filePath = Paths.get(DATA_DIRECTORY, fileName);
        // Create file if it doesn't exist
        if (!Files.exists(filePath)) {
            Files.createFile(filePath);
        }
        Files.write(filePath, List.of(line), StandardOpenOption.APPEND);
    }
    
    // Read all lines from a file
    public List<String> readLinesFromFile(String fileName) throws IOException {
        Path filePath = Paths.get(DATA_DIRECTORY, fileName);
        if (!Files.exists(filePath)) {
            return new ArrayList<>();
        }
        return Files.readAllLines(filePath);
    }
    
    // Update a specific line in a file
    public void updateLineInFile(String fileName, String oldLine, String newLine) throws IOException {
        Path filePath = Paths.get(DATA_DIRECTORY, fileName);
        if (!Files.exists(filePath)) {
            throw new FileNotFoundException("File not found: " + fileName);
        }
        
        List<String> lines = Files.readAllLines(filePath);
        List<String> updatedLines = lines.stream()
                .map(line -> line.equals(oldLine) ? newLine : line)
                .collect(Collectors.toList());
        
        Files.write(filePath, updatedLines, StandardOpenOption.TRUNCATE_EXISTING);
    }
    
    // Delete a specific line from a file
    public void deleteLineFromFile(String fileName, String lineToDelete) throws IOException {
        Path filePath = Paths.get(DATA_DIRECTORY, fileName);
        if (!Files.exists(filePath)) {
            throw new FileNotFoundException("File not found: " + fileName);
        }
        
        List<String> lines = Files.readAllLines(filePath);
        List<String> updatedLines = lines.stream()
                .filter(line -> !line.equals(lineToDelete))
                .collect(Collectors.toList());
        
        Files.write(filePath, updatedLines, StandardOpenOption.TRUNCATE_EXISTING);
    }
}