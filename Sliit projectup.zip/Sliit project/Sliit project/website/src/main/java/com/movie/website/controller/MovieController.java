package com.movie.website.controller;

import com.movie.website.model.Movie;
import com.movie.website.service.MovieService;
import com.movie.website.service.SubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/movies")
public class MovieController {

    @Autowired
    private MovieService movieService;
    
    @Autowired
    private SubscriptionService subscriptionService;

    @GetMapping
    public String getAllMovies(Model model, @RequestParam(required = false) String userId) {
        List<Movie> movies = movieService.getAllMovies();
        model.addAttribute("movies", movies);
        
        // Check if user has active subscription (for UI customization)
        if (userId != null && !userId.isEmpty()) {
            boolean hasActiveSubscription = subscriptionService.hasActiveSubscription(userId);
            model.addAttribute("hasActiveSubscription", hasActiveSubscription);
            model.addAttribute("userId", userId);
        }
        
        return "movie/list";
    }

    @GetMapping("/{id}")
    public String getMovieDetails(@PathVariable String id, @RequestParam(required = false) String userId, Model model) {
        Movie movie = movieService.getMovieById(id);
        model.addAttribute("movie", movie);
        
        // Check if user has active subscription (for pricing)
        if (userId != null && !userId.isEmpty()) {
            boolean hasActiveSubscription = subscriptionService.hasActiveSubscription(userId);
            model.addAttribute("hasActiveSubscription", hasActiveSubscription);
            model.addAttribute("userId", userId);
            
            // Calculate rental price (with discount for subscribers)
            double rentalPrice = movie.getRentalPrice();
            if (hasActiveSubscription) {
                rentalPrice = rentalPrice * 0.8; // 20% discount for subscribers
            }
            model.addAttribute("rentalPrice", rentalPrice);
        }
        
        return "movie/details";
    }

    // Admin endpoints
    @GetMapping("/admin/add")
    public String showAddMovieForm(Model model) {
        model.addAttribute("movie", new Movie());
        return "admin/add-movie";
    }

    @PostMapping("/admin/add")
    public String addMovie(@ModelAttribute Movie movie) {
        movieService.addMovie(movie);
        return "redirect:/movies";
    }

    @GetMapping("/admin/edit/{id}")
    public String showEditMovieForm(@PathVariable String id, Model model) {
        Movie movie = movieService.getMovieById(id);
        model.addAttribute("movie", movie);
        return "admin/edit-movie";
    }

    @PostMapping("/admin/edit")
    public String editMovie(@ModelAttribute Movie movie) {
        movieService.updateMovie(movie);
        return "redirect:/movies";
    }

    @PostMapping("/admin/delete")
    public String deleteMovie(@RequestParam String id) {
        movieService.deleteMovie(id);
        return "redirect:/movies";
    }
}