package com.movie.website.service;

import com.movie.website.model.Subscription;
import com.movie.website.model.SubscriptionPlan;
import com.movie.website.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class SubscriptionService {

    private static final String DATA_DIR = "data";
    private static final String SUBSCRIPTIONS_FILE = DATA_DIR + "/subscriptions.dat";
    private List<Subscription> subscriptions;

    @Autowired
    private SubscriptionPlanService subscriptionPlanService;

    @PostConstruct
    public void init() {
        FileUtil.ensureDirectoryExists(DATA_DIR);
        this.subscriptions = FileUtil.readFromFile(SUBSCRIPTIONS_FILE);
    }

    public List<Subscription> getAllSubscriptions() {
        return subscriptions;
    }

    public List<Subscription> getSubscriptionsByUserId(String userId) {
        return subscriptions.stream()
                .filter(subscription -> subscription.getUserId().equals(userId))
                .collect(Collectors.toList());
    }

    public Subscription getActiveSubscriptionForUser(String userId) {
        return subscriptions.stream()
                .filter(subscription -> subscription.getUserId().equals(userId) && 
                                       subscription.isActive() && 
                                       subscription.getEndDate().isAfter(LocalDate.now()))
                .findFirst()
                .orElse(null);
    }

    public Subscription getSubscriptionById(String id) {
        return subscriptions.stream()
                .filter(subscription -> subscription.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Subscription createSubscription(String userId, String subscriptionPlanId) {
        SubscriptionPlan plan = subscriptionPlanService.getSubscriptionPlanById(subscriptionPlanId);
        if (plan == null) {
            throw new IllegalArgumentException("Subscription plan not found");
        }

        // Cancel any active subscriptions for this user
        cancelActiveSubscriptionsForUser(userId);

        LocalDate startDate = LocalDate.now();
        LocalDate endDate = startDate.plusDays(plan.getDurationInDays());

        Subscription subscription = new Subscription(
                UUID.randomUUID().toString(),
                userId,
                subscriptionPlanId,
                startDate,
                endDate,
                true
        );

        subscriptions.add(subscription);
        saveSubscriptions();
        return subscription;
    }

    public void cancelSubscription(String subscriptionId) {
        subscriptions = subscriptions.stream()
                .map(subscription -> {
                    if (subscription.getId().equals(subscriptionId)) {
                        subscription.setActive(false);
                    }
                    return subscription;
                })
                .collect(Collectors.toList());
        saveSubscriptions();
    }

    private void cancelActiveSubscriptionsForUser(String userId) {
        subscriptions = subscriptions.stream()
                .map(subscription -> {
                    if (subscription.getUserId().equals(userId) && subscription.isActive()) {
                        subscription.setActive(false);
                    }
                    return subscription;
                })
                .collect(Collectors.toList());
        saveSubscriptions();
    }

    public boolean hasActiveSubscription(String userId) {
        return getActiveSubscriptionForUser(userId) != null;
    }

    private void saveSubscriptions() {
        FileUtil.writeToFile(subscriptions, SUBSCRIPTIONS_FILE);
    }
}