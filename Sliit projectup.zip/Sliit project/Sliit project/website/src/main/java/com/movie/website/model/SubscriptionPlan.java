package com.movie.website.model;

import java.io.Serializable;

public class SubscriptionPlan implements Serializable {

    private String id;
    private String name;
    private double price;
    private int durationInDays;
    private String description;

    // Constructors, getters, setters, and toString() method
    public SubscriptionPlan() {}

    public SubscriptionPlan(String id, String name, double price, int durationInDays, String description) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.durationInDays = durationInDays;
        this.description = description;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getDurationInDays() { return durationInDays; }
    public void setDurationInDays(int durationInDays) { this.durationInDays = durationInDays; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    @Override
    public String toString() {
        return "SubscriptionPlan{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", durationInDays=" + durationInDays +
                ", description='" + description + '\'' +
                '}';
    }
}