package com.movieapp.servlet;

import com.movieapp.service.RentalService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/watch")
public class WatchServlet extends HttpServlet {
    private final RentalService rentalService = new RentalService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String movieId = request.getParameter("movieId");
        if (movieId == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Movie ID is required");
            return;
        }
        
        // Check if the user has an active rental for this movie
        if (!rentalService.hasActiveRental(userId, movieId)) {
            response.sendRedirect(request.getContextPath() + "/rent?movieId=" + movieId);
            return;
        }
        
        // Set movie details for the view
        request.setAttribute("movieId", movieId);
        
        request.getRequestDispatcher("/WEB-INF/views/watch-movie.jsp").forward(request, response);
    }
}