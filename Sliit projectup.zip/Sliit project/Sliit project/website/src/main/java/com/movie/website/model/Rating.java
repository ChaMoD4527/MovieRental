package com.movie.website.model;

import java.io.Serializable;

public class Rating implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String id;
    private String userId;
    private String movieId;
    private int stars;
    private String comment;

    public Rating(String id, String userId, String movieId, int stars, String comment) {
        this.id = id;
        this.userId = userId;
        this.movieId = movieId;
        this.stars = stars;
        this.comment = comment;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
