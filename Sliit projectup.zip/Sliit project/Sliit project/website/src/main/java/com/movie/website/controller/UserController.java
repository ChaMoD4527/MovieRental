package com.movie.website.controller;

import com.movie.website.data.DataStore;
import com.movie.website.model.Movie;
import com.movie.website.model.Rating;
import com.movie.website.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.logging.Level;

@Controller
public class UserController {
    private static final Logger logger = Logger.getLogger(UserController.class.getName());
    private final DataStore dataStore = DataStore.getInstance();
    
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }
    
    @PostMapping("/login")
    public String login(@RequestParam String username, 
                        @RequestParam String password,
                        HttpSession session,
                        Model model,
                        RedirectAttributes redirectAttributes) {
        
        try {
            if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
                model.addAttribute("error", "Username and password are required");
                return "login";
            }
            
            User user = dataStore.getUserByUsername(username);
            
            if (user != null && user.getPassword().equals(password)) {
                session.setAttribute("user", user);
                logger.info("User logged in: " + username);
                
                if (user.isAdmin()) {
                    return "redirect:/admin/dashboard";
                } else {
                    return "redirect:/";
                }
            } else {
                model.addAttribute("error", "Invalid username or password");
                logger.warning("Failed login attempt for username: " + username);
                return "login";
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error during login", e);
            model.addAttribute("error", "An error occurred during login");
            return "login";
        }
    }
    
    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }
    
    @PostMapping("/register")
    public String register(@RequestParam String username,
                          @RequestParam String password,
                          @RequestParam String email,
                          Model model,
                          RedirectAttributes redirectAttributes) {
        
        try {
            // Validate input
            if (username == null || username.trim().isEmpty()) {
                model.addAttribute("error", "Username is required");
                return "register";
            }
            
            if (password == null || password.trim().isEmpty()) {
                model.addAttribute("error", "Password is required");
                return "register";
            }
            
            if (email == null || email.trim().isEmpty() || !email.contains("@")) {
                model.addAttribute("error", "Valid email is required");
                return "register";
            }
            
            // Check if username already exists
            if (dataStore.getUserByUsername(username) != null) {
                model.addAttribute("error", "Username already exists");
                return "register";
            }
            
            // Create new user
            User newUser = new User(UUID.randomUUID().toString(), username, password, email, false);
            dataStore.addUser(newUser);
            logger.info("New user registered: " + username);
            
            redirectAttributes.addFlashAttribute("registered", true);
            return "redirect:/login";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error during registration", e);
            model.addAttribute("error", "An error occurred during registration");
            return "register";
        }
    }
    
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user != null) {
            logger.info("User logged out: " + user.getUsername());
        }
        session.invalidate();
        return "redirect:/";
    }
    
    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null) {
                logger.warning("Unauthorized access to profile page");
                return "redirect:/login";
            }
            
            // Get user's ratings
            List<Rating> userRatings = dataStore.getRatingsByUserId(user.getId());
            
            // Get rated movies
            List<Movie> ratedMovies = new ArrayList<>();
            for (Rating rating : userRatings) {
                Movie movie = dataStore.getMovieById(rating.getMovieId());
                if (movie != null) {
                    ratedMovies.add(movie);
                }
            }
            
            // Get watch history
            List<String> watchHistory = (List<String>) session.getAttribute("watchHistory");
            List<Movie> watchedMovies = new ArrayList<>();
            
            if (watchHistory != null && !watchHistory.isEmpty()) {
                for (String movieId : watchHistory) {
                    Movie movie = dataStore.getMovieById(movieId);
                    if (movie != null) {
                        watchedMovies.add(movie);
                    }
                }
            }
            
            model.addAttribute("user", user);
            model.addAttribute("ratedMovies", ratedMovies);
            model.addAttribute("watchedMovies", watchedMovies);
            
            logger.info("User accessed profile page: " + user.getUsername());
            return "profile";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing profile page", e);
            model.addAttribute("error", "An error occurred while retrieving your profile");
            return "error/general";
        }
    }

    @GetMapping("/edit-profile")
    public String editProfileForm(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");

            if (user == null) {
                logger.warning("Unauthorized access to edit profile page");
                return "redirect:/login";
            }

            model.addAttribute("user", user);
            logger.info("User accessed edit profile form: " + user.getUsername());
            return "edit-profile";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing edit profile form", e);
            model.addAttribute("error", "An error occurred while retrieving your profile data");
            return "error/general";
        }
    }

    @PostMapping("/edit-profile")
    public String editProfile(@RequestParam String username,
                             @RequestParam String email,
                             @RequestParam(required = false) String password,
                             HttpSession session,
                             Model model,
                             RedirectAttributes redirectAttributes) {

        try {
            User user = (User) session.getAttribute("user");

            if (user == null) {
                logger.warning("Unauthorized attempt to edit profile");
                return "redirect:/login";
            }

            // Validate input
            if (username == null || username.trim().isEmpty()) {
                model.addAttribute("error", "Username is required");
                model.addAttribute("user", user);
                return "edit-profile";
            }

            if (email == null || email.trim().isEmpty() || !email.contains("@")) {
                model.addAttribute("error", "Valid email is required");
                model.addAttribute("user", user);
                return "edit-profile";
            }

            // Check if username already exists (if changed)
            if (!user.getUsername().equals(username)) {
                User existingUser = dataStore.getUserByUsername(username);
                if (existingUser != null) {
                    model.addAttribute("error", "Username already exists");
                    model.addAttribute("user", user);
                    return "edit-profile";
                }
            }

            // Update user information
            user.setUsername(username);
            user.setEmail(email);

            // Update password if provided
            if (password != null && !password.trim().isEmpty()) {
                user.setPassword(password);
            }

            // Update session
            session.setAttribute("user", user);
            logger.info("User profile updated: " + user.getUsername());

            redirectAttributes.addFlashAttribute("success", "Profile updated successfully");
            return "redirect:/profile?updated=true";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error updating profile", e);
            model.addAttribute("error", "An error occurred while updating your profile");
            model.addAttribute("user", (User) session.getAttribute("user"));
            return "edit-profile";
        }
    }
}
