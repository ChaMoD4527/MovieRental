package com.movie.website.controller;

import com.movie.website.data.DataStore;
import com.movie.website.model.Movie;
import com.movie.website.model.Payment;
import com.movie.website.model.Rating;
import com.movie.website.model.Subscription;
import com.movie.website.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.logging.Logger;
import java.util.logging.Level;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private static final Logger logger = Logger.getLogger(AdminController.class.getName());
    private final DataStore dataStore = DataStore.getInstance();
    
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized access attempt to admin dashboard");
                return "redirect:/login";
            }
            
            List<Movie> topRated = dataStore.getTopRatedMovies();
            List<Payment> unverifiedPayments = dataStore.getUnverifiedPayments();
            
            model.addAttribute("topRated", topRated);
            model.addAttribute("unverifiedPayments", unverifiedPayments);
            model.addAttribute("totalMovies", dataStore.getAllMovies().size());
            model.addAttribute("totalUsers", dataStore.getAllUsers().size());
            
            logger.info("Admin accessed dashboard: " + user.getUsername());
            return "admin/dashboard";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing admin dashboard", e);
            model.addAttribute("error", "An error occurred while loading the admin dashboard");
            return "error/general";
        }
    }
    
    @GetMapping("/movies")
    public String manageMovies(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized access attempt to manage movies");
                return "redirect:/login";
            }
            
            List<Movie> movies = dataStore.getAllMovies();
            model.addAttribute("movies", movies);
            
            logger.info("Admin accessed movie management: " + user.getUsername());
            return "admin/manage-movies";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing movie management", e);
            model.addAttribute("error", "An error occurred while loading the movie management page");
            return "error/general";
        }
    }
    
    @GetMapping("/movies/add")
    public String addMovieForm(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized access attempt to add movie form");
                return "redirect:/login";
            }
            
            logger.info("Admin accessed add movie form: " + user.getUsername());
            return "admin/add-movie";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing add movie form", e);
            model.addAttribute("error", "An error occurred while loading the add movie form");
            return "error/general";
        }
    }
    
    @PostMapping("/movies/add")
    public String addMovie(@RequestParam String title,
                          @RequestParam String description,
                          @RequestParam String category,
                          @RequestParam String imageUrl,
                          @RequestParam String videoUrl,
                          @RequestParam double rentalPrice,
                          @RequestParam(required = false) boolean isNewArrival,
                          @RequestParam(required = false) boolean isTvSeries,
                          HttpSession session,
                          Model model,
                          RedirectAttributes redirectAttributes) {
        
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized attempt to add movie");
                return "redirect:/login";
            }
            
            // Validate input
            if (title == null || title.trim().isEmpty()) {
                model.addAttribute("error", "Title is required");
                return "admin/add-movie";
            }
            
            if (description == null || description.trim().isEmpty()) {
                model.addAttribute("error", "Description is required");
                return "admin/add-movie";
            }
            
            if (category == null || category.trim().isEmpty()) {
                model.addAttribute("error", "Category is required");
                return "admin/add-movie";
            }
            
            if (imageUrl == null || imageUrl.trim().isEmpty()) {
                model.addAttribute("error", "Image URL is required");
                return "admin/add-movie";
            }
            
            if (videoUrl == null || videoUrl.trim().isEmpty()) {
                model.addAttribute("error", "Video URL is required");
                return "admin/add-movie";
            }
            
            if (rentalPrice < 0) {
                model.addAttribute("error", "Rental price must be non-negative");
                return "admin/add-movie";
            }
            
            Movie movie = new Movie(
                UUID.randomUUID().toString(),
                title,
                description,
                category,
                imageUrl,
                videoUrl,
                rentalPrice
            );
            
            movie.setNewArrival(isNewArrival);
            movie.setTvSeries(isTvSeries);
            
            dataStore.addMovie(movie);
            logger.info("Admin added new movie: " + title + " by " + user.getUsername());
            
            redirectAttributes.addFlashAttribute("success", "Movie added successfully");
            return "redirect:/admin/movies";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error adding movie", e);
            model.addAttribute("error", "An error occurred while adding the movie");
            return "admin/add-movie";
        }
    }
    
    @GetMapping("/movies/edit/{id}")
    public String editMovieForm(@PathVariable String id, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized access attempt to edit movie form");
                return "redirect:/login";
            }
            
            Movie movie = dataStore.getMovieById(id);
            
            if (movie == null) {
                logger.warning("Attempt to edit non-existent movie with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "Movie not found");
                return "redirect:/admin/movies";
            }
            
            model.addAttribute("movie", movie);
            logger.info("Admin accessed edit movie form for: " + movie.getTitle());
            return "admin/edit-movie";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing edit movie form for ID: " + id, e);
            model.addAttribute("error", "An error occurred while loading the edit movie form");
            return "error/general";
        }
    }
    
    @PostMapping("/movies/edit/{id}")
    public String editMovie(@PathVariable String id,
                           @RequestParam String title,
                           @RequestParam String description,
                           @RequestParam String category,
                           @RequestParam String imageUrl,
                           @RequestParam String videoUrl,
                           @RequestParam double rentalPrice,
                           @RequestParam(required = false) boolean isNewArrival,
                           @RequestParam(required = false) boolean isTvSeries,
                           HttpSession session,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized attempt to edit movie");
                return "redirect:/login";
            }
            
            Movie movie = dataStore.getMovieById(id);
            
            if (movie == null) {
                logger.warning("Attempt to edit non-existent movie with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "Movie not found");
                return "redirect:/admin/movies";
            }
            
            // Validate input
            if (title == null || title.trim().isEmpty()) {
                model.addAttribute("error", "Title is required");
                model.addAttribute("movie", movie);
                return "admin/edit-movie";
            }
            
            if (description == null || description.trim().isEmpty()) {
                model.addAttribute("error", "Description is required");
                model.addAttribute("movie", movie);
                return "admin/edit-movie";
            }
            
            if (category == null || category.trim().isEmpty()) {
                model.addAttribute("error", "Category is required");
                model.addAttribute("movie", movie);
                return "admin/edit-movie";
            }
            
            if (imageUrl == null || imageUrl.trim().isEmpty()) {
                model.addAttribute("error", "Image URL is required");
                model.addAttribute("movie", movie);
                return "admin/edit-movie";
            }
            
            if (videoUrl == null || videoUrl.trim().isEmpty()) {
                model.addAttribute("error", "Video URL is required");
                model.addAttribute("movie", movie);
                return "admin/edit-movie";
            }
            
            if (rentalPrice < 0) {
                model.addAttribute("error", "Rental price must be non-negative");
                model.addAttribute("movie", movie);
                return "admin/edit-movie";
            }
            
            movie.setTitle(title);
            movie.setDescription(description);
            movie.setCategory(category);
            movie.setImageUrl(imageUrl);
            movie.setVideoUrl(videoUrl);
            movie.setRentalPrice(rentalPrice);
            movie.setNewArrival(isNewArrival);
            movie.setTvSeries(isTvSeries);
            
            logger.info("Admin updated movie: " + title + " by " + user.getUsername());
            redirectAttributes.addFlashAttribute("success", "Movie updated successfully");
            return "redirect:/admin/movies";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error editing movie with ID: " + id, e);
            model.addAttribute("error", "An error occurred while updating the movie");
            model.addAttribute("movie", dataStore.getMovieById(id));
            return "admin/edit-movie";
        }
    }
    
    @PostMapping("/movies/delete/{id}")
    public String deleteMovie(@PathVariable String id, HttpSession session, RedirectAttributes redirectAttributes) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized attempt to delete movie");
                return "redirect:/login";
            }
            
            Movie movie = dataStore.getMovieById(id);
            if (movie == null) {
                logger.warning("Attempt to delete non-existent movie with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "Movie not found");
                return "redirect:/admin/movies";
            }
            
            boolean deleted = dataStore.deleteMovie(id);
            
            if (deleted) {
                logger.info("Admin deleted movie: " + movie.getTitle() + " by " + user.getUsername());
                redirectAttributes.addFlashAttribute("success", "Movie deleted successfully");
            } else {
                logger.warning("Failed to delete movie with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "Failed to delete movie");
            }
            
            return "redirect:/admin/movies";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error deleting movie with ID: " + id, e);
            redirectAttributes.addFlashAttribute("error", "An error occurred while deleting the movie");
            return "redirect:/admin/movies";
        }
    }
    
    @GetMapping("/users")
    public String manageUsers(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized access attempt to manage users");
                return "redirect:/login";
            }
            
            List<User> users = dataStore.getAllUsers();
            model.addAttribute("users", users);
            
            logger.info("Admin accessed user management: " + user.getUsername());
            return "admin/users";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing user management", e);
            model.addAttribute("error", "An error occurred while loading the user management page");
            return "error/general";
        }
    }
    
    @GetMapping("/users/{id}")
    public String userDetails(@PathVariable String id, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        try {
            User admin = (User) session.getAttribute("user");
            
            if (admin == null || !admin.isAdmin()) {
                logger.warning("Unauthorized access attempt to user details");
                return "redirect:/login";
            }
            
            User user = dataStore.getUserById(id);
            
            if (user == null) {
                logger.warning("Attempt to view non-existent user with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "User not found");
                return "redirect:/admin/users";
            }
            
            // Get user's payments
            List<Payment> allPayments = dataStore.getAllPayments();
            List<Payment> userPayments = allPayments.stream()
                .filter(payment -> payment.getUserId().equals(id))
                .collect(Collectors.toList());
            
            // Get user's ratings
            List<Rating> userRatings = dataStore.getRatingsByUserId(id);
            
            model.addAttribute("user", user);
            model.addAttribute("payments", userPayments);
            model.addAttribute("ratings", userRatings);
            
            logger.info("Admin viewed user details for: " + user.getUsername());
            return "admin/user-details";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing user details for ID: " + id, e);
            model.addAttribute("error", "An error occurred while loading the user details");
            return "error/general";
        }
    }
    
    @PostMapping("/verify-payment/{id}")
    public String verifyPayment(@PathVariable String id, HttpSession session, RedirectAttributes redirectAttributes) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized attempt to verify payment");
                return "redirect:/login";
            }
            
            Payment payment = dataStore.getPaymentById(id);
            
            if (payment == null) {
                logger.warning("Attempt to verify non-existent payment with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "Payment not found");
                return "redirect:/admin/payments";
            }
            
            payment.setVerified(true);
            
            // Update user subscription status
            User paymentUser = dataStore.getUserById(payment.getUserId());
            if (paymentUser != null) {
                paymentUser.setSubscribed(true);
                Subscription subscription = dataStore.getSubscriptionById(payment.getSubscriptionId());
                if (subscription != null) {
                    paymentUser.setSubscriptionType(subscription.getName());
                    logger.info("User " + paymentUser.getUsername() + " subscription activated: " + subscription.getName());
                }
            }
            
            logger.info("Admin verified payment: " + id + " by " + user.getUsername());
            redirectAttributes.addFlashAttribute("success", "Payment verified successfully");
            return "redirect:/admin/payments";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error verifying payment with ID: " + id, e);
            redirectAttributes.addFlashAttribute("error", "An error occurred while verifying the payment");
            return "redirect:/admin/payments";
        }
    }
    
    @GetMapping("/payments")
    public String managePayments(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized access attempt to manage payments");
                return "redirect:/login";
            }
            
            List<Payment> payments = dataStore.getAllPayments();
            model.addAttribute("payments", payments);
            
            logger.info("Admin accessed payment management: " + user.getUsername());
            return "admin/manage-payments";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing payment management", e);
            model.addAttribute("error", "An error occurred while loading the payment management page");
            return "error/general";
        }
    }
    
    @GetMapping("/subscriptions")
    public String manageSubscriptions(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized access attempt to manage subscriptions");
                return "redirect:/login";
            }
            
            List<Subscription> subscriptions = dataStore.getAllSubscriptions();
            model.addAttribute("subscriptions", subscriptions);
            
            logger.info("Admin accessed subscription management: " + user.getUsername());
            return "admin/manage-subscriptions";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing subscription management", e);
            model.addAttribute("error", "An error occurred while loading the subscription management page");
            return "error/general";
        }
    }
    
    @GetMapping("/subscriptions/add")
    public String addSubscriptionForm(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized access attempt to add subscription form");
                return "redirect:/login";
            }
            
            logger.info("Admin accessed add subscription form: " + user.getUsername());
            return "admin/add-subscription";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing add subscription form", e);
            model.addAttribute("error", "An error occurred while loading the add subscription form");
            return "error/general";
        }
    }
    
    @PostMapping("/subscriptions/add")
    public String addSubscription(@RequestParam String name,
                                 @RequestParam String description,
                                 @RequestParam double price,
                                 @RequestParam int duration,
                                 @RequestParam int maxUsers,
                                 HttpSession session,
                                 Model model,
                                 RedirectAttributes redirectAttributes) {
        
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized attempt to add subscription");
                return "redirect:/login";
            }
            
            // Validate input
            if (name == null || name.trim().isEmpty()) {
                model.addAttribute("error", "Name is required");
                return "admin/add-subscription";
            }
            
            if (description == null || description.trim().isEmpty()) {
                model.addAttribute("error", "Description is required");
                return "admin/add-subscription";
            }
            
            if (price < 0) {
                model.addAttribute("error", "Price must be non-negative");
                return "admin/add-subscription";
            }
            
            if (duration <= 0) {
                model.addAttribute("error", "Duration must be positive");
                return "admin/add-subscription";
            }
            
            if (maxUsers <= 0) {
                model.addAttribute("error", "Max users must be positive");
                return "admin/add-subscription";
            }
            
            Subscription subscription = new Subscription(
                UUID.randomUUID().toString(),
                name,
                description,
                price,
                duration,
                maxUsers
            );
            
            dataStore.addSubscription(subscription);
            logger.info("Admin added new subscription: " + name + " by " + user.getUsername());
            
            redirectAttributes.addFlashAttribute("success", "Subscription added successfully");
            return "redirect:/admin/subscriptions";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error adding subscription", e);
            model.addAttribute("error", "An error occurred while adding the subscription");
            return "admin/add-subscription";
        }
    }
    
    @GetMapping("/subscriptions/edit/{id}")
    public String editSubscriptionForm(@PathVariable String id, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized access attempt to edit subscription form");
                return "redirect:/login";
            }
            
            Subscription subscription = dataStore.getSubscriptionById(id);
            
            if (subscription == null) {
                logger.warning("Attempt to edit non-existent subscription with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "Subscription not found");
                return "redirect:/admin/subscriptions";
            }
            
            model.addAttribute("subscription", subscription);
            logger.info("Admin accessed edit subscription form for: " + subscription.getName());
            return "admin/edit-subscription";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error accessing edit subscription form for ID: " + id, e);
            model.addAttribute("error", "An error occurred while loading the edit subscription form");
            return "error/general";
        }
    }
    
    @PostMapping("/subscriptions/edit/{id}")
    public String editSubscription(@PathVariable String id,
                                  @RequestParam String name,
                                  @RequestParam String description,
                                  @RequestParam double price,
                                  @RequestParam int duration,
                                  @RequestParam int maxUsers,
                                  HttpSession session,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized attempt to edit subscription");
                return "redirect:/login";
            }
            
            Subscription subscription = dataStore.getSubscriptionById(id);
            
            if (subscription == null) {
                logger.warning("Attempt to edit non-existent subscription with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "Subscription not found");
                return "redirect:/admin/subscriptions";
            }
            
            // Validate input
            if (name == null || name.trim().isEmpty()) {
                model.addAttribute("error", "Name is required");
                model.addAttribute("subscription", subscription);
                return "admin/edit-subscription";
            }
            
            if (description == null || description.trim().isEmpty()) {
                model.addAttribute("error", "Description is required");
                model.addAttribute("subscription", subscription);
                return "admin/edit-subscription";
            }
            
            if (price < 0) {
                model.addAttribute("error", "Price must be non-negative");
                model.addAttribute("subscription", subscription);
                return "admin/edit-subscription";
            }
            
            if (duration <= 0) {
                model.addAttribute("error", "Duration must be positive");
                model.addAttribute("subscription", subscription);
                return "admin/edit-subscription";
            }
            
            if (maxUsers <= 0) {
                model.addAttribute("error", "Max users must be positive");
                model.addAttribute("subscription", subscription);
                return "admin/edit-subscription";
            }
            
            subscription.setName(name);
            subscription.setDescription(description);
            subscription.setPrice(price);
            subscription.setDuration(duration);
            subscription.setMaxUsers(maxUsers);
            
            logger.info("Admin updated subscription: " + name + " by " + user.getUsername());
            redirectAttributes.addFlashAttribute("success", "Subscription updated successfully");
            return "redirect:/admin/subscriptions";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error editing subscription with ID: " + id, e);
            model.addAttribute("error", "An error occurred while updating the subscription");
            model.addAttribute("subscription", dataStore.getSubscriptionById(id));
            return "admin/edit-subscription";
        }
    }
    
    @PostMapping("/subscriptions/delete/{id}")
    public String deleteSubscription(@PathVariable String id, HttpSession session, RedirectAttributes redirectAttributes) {
        try {
            User user = (User) session.getAttribute("user");
            
            if (user == null || !user.isAdmin()) {
                logger.warning("Unauthorized attempt to delete subscription");
                return "redirect:/login";
            }
            
            Subscription subscription = dataStore.getSubscriptionById(id);
            if (subscription == null) {
                logger.warning("Attempt to delete non-existent subscription with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "Subscription not found");
                return "redirect:/admin/subscriptions";
            }
            
            boolean deleted = dataStore.deleteSubscription(id);
            
            if (deleted) {
                logger.info("Admin deleted subscription: " + subscription.getName() + " by " + user.getUsername());
                redirectAttributes.addFlashAttribute("success", "Subscription deleted successfully");
            } else {
                logger.warning("Failed to delete subscription with ID: " + id);
                redirectAttributes.addFlashAttribute("error", "Failed to delete subscription");
            }
            
            return "redirect:/admin/subscriptions";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error deleting subscription with ID: " + id, e);
            redirectAttributes.addFlashAttribute("error", "An error occurred while deleting the subscription");
            return "redirect:/admin/subscriptions";
        }
    }
}
