package com.movieapp.model;

import java.io.Serializable;

public class CardDetails implements Serializable {
    private String userId;
    private String cardNumber;
    private String cardholderName;
    private String expiryMonth;
    private String expiryYear;
    private String cvc;
    private boolean isDefault;

    public CardDetails() {
    }

    public CardDetails(String userId, String cardNumber, String cardholderName, 
                      String expiryMonth, String expiryYear, String cvc, boolean isDefault) {
        this.userId = userId;
        this.cardNumber = cardNumber;
        this.cardholderName = cardholderName;
        this.expiryMonth = expiryMonth;
        this.expiryYear = expiryYear;
        this.cvc = cvc;
        this.isDefault = isDefault;
    }

    // Getters and setters
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardholderName() {
        return cardholderName;
    }

    public void setCardholderName(String cardholderName) {
        this.cardholderName = cardholderName;
    }

    public String getExpiryMonth() {
        return expiryMonth;
    }

    public void setExpiryMonth(String expiryMonth) {
        this.expiryMonth = expiryMonth;
    }

    public String getExpiryYear() {
        return expiryYear;
    }

    public void setExpiryYear(String expiryYear) {
        this.expiryYear = expiryYear;
    }

    public String getCvc() {
        return cvc;
    }

    public void setCvc(String cvc) {
        this.cvc = cvc;
    }

    public boolean isDefault() {
        return isDefault;
    }

    public void setDefault(boolean isDefault) {
        this.isDefault = isDefault;
    }

    // For file storage - convert to CSV format
    public String toCsvString() {
        return userId + "," + cardNumber + "," + cardholderName + "," + 
               expiryMonth + "," + expiryYear + "," + cvc + "," + isDefault;
    }

    // For file storage - parse from CSV format
    public static CardDetails fromCsvString(String csvLine) {
        String[] parts = csvLine.split(",");
        if (parts.length != 7) {
            throw new IllegalArgumentException("Invalid CSV format for CardDetails");
        }
        
        return new CardDetails(
            parts[0], // userId
            parts[1], // cardNumber
            parts[2], // cardholderName
            parts[3], // expiryMonth
            parts[4], // expiryYear
            parts[5], // cvc
            Boolean.parseBoolean(parts[6]) // isDefault
        );
    }

    // For security, mask the card number when displaying
    public String getMaskedCardNumber() {
        if (cardNumber == null || cardNumber.length() < 4) {
            return "****";
        }
        return "****" + cardNumber.substring(cardNumber.length() - 4);
    }
}