package com.movie.website.controller;

import com.movie.website.data.DataStore;
import com.movie.website.model.Movie;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.stream.Collectors;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.ArrayList;

@Controller
public class SearchController {
    private static final Logger logger = Logger.getLogger(SearchController.class.getName());
    private final DataStore dataStore = DataStore.getInstance();
    
    @GetMapping("/search")
    public String search(@RequestParam(required = false) String query,
                        @RequestParam(required = false) String category,
                        @RequestParam(required = false) String sort,
                        Model model) {
        
        try {
            List<Movie> movies = dataStore.getAllMovies();
            int initialCount = movies.size();
            
            // Filter by search query
            if (query != null && !query.trim().isEmpty()) {
                String lowerQuery = query.toLowerCase();
                movies = movies.stream()
                    .filter(movie -> 
                        movie.getTitle().toLowerCase().contains(lowerQuery) ||
                        movie.getDescription().toLowerCase().contains(lowerQuery) ||
                        movie.getCategory().toLowerCase().contains(lowerQuery))
                    .collect(Collectors.toList());
                logger.info("Search query: '" + query + "' filtered movies from " + initialCount + " to " + movies.size());
            }
            
            // Filter by category
            if (category != null && !category.trim().isEmpty() && !category.equals("all")) {
                int beforeFilter = movies.size();
                movies = movies.stream()
                    .filter(movie -> movie.getCategory().equalsIgnoreCase(category))
                    .collect(Collectors.toList());
                logger.info("Category filter: '" + category + "' filtered movies from " + beforeFilter + " to " + movies.size());
            }
            
            // Sort results
            if (sort != null && !sort.trim().isEmpty()) {
                switch (sort) {
                    case "rating":
                        movies.sort((a, b) -> Double.compare(b.getAverageRating(), a.getAverageRating()));
                        logger.info("Sorted movies by rating");
                        break;
                    case "title":
                        movies.sort((a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));
                        logger.info("Sorted movies by title");
                        break;
                    case "price_asc":
                        movies.sort((a, b) -> Double.compare(a.getRentalPrice(), b.getRentalPrice()));
                        logger.info("Sorted movies by price (ascending)");
                        break;
                    case "price_desc":
                        movies.sort((a, b) -> Double.compare(b.getRentalPrice(), a.getRentalPrice()));
                        logger.info("Sorted movies by price (descending)");
                        break;
                    case "newest":
                        int beforeFilter = movies.size();
                        movies = movies.stream()
                            .filter(Movie::isNewArrival)
                            .collect(Collectors.toList());
                        logger.info("Filtered for new arrivals: from " + beforeFilter + " to " + movies.size() + " movies");
                        break;
                    default:
                        // Default sort by title
                        movies.sort((a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));
                        logger.info("Applied default sort by title");
                }
            } else {
                // Default sort by title if no sort parameter
                movies.sort((a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));
            }
            
            // Add data to model
            model.addAttribute("movies", movies);
            model.addAttribute("query", query);
            model.addAttribute("selectedCategory", category);
            model.addAttribute("selectedSort", sort);
            model.addAttribute("resultCount", movies.size());
            
            // Get all available categories for filter dropdown
            List<String> categories = dataStore.getAllMovies().stream()
                .map(Movie::getCategory)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
            model.addAttribute("categories", categories);
            
            logger.info("Search results: " + movies.size() + " movies found");
            return "search-results";
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error during search", e);
            model.addAttribute("error", "An error occurred while searching");
            model.addAttribute("movies", new ArrayList<Movie>());
            model.addAttribute("query", query);
            model.addAttribute("selectedCategory", category);
            model.addAttribute("selectedSort", sort);
            model.addAttribute("categories", new ArrayList<String>());
            model.addAttribute("resultCount", 0);
            return "search-results";
        }
    }
}
