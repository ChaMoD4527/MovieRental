package com.movie.website.controller;

import com.movie.website.model.Rental;
import com.movie.website.service.RentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/rentals")
public class RentalController {

    @Autowired
    private RentalService rentalService;

    @GetMapping("/my-rentals")
    public String getMyRentals(@RequestParam String userId, Model model) {
        List<Rental> rentals = rentalService.getRentalsByUserId(userId);
        model.addAttribute("rentals", rentals);
        return "rental/my-rentals";
    }

    @GetMapping("/rent")
    public String showRentForm(@RequestParam String userId, @RequestParam String movieId, 
                              @RequestParam String movieTitle, @RequestParam double price, Model model) {
        model.addAttribute("userId", userId);
        model.addAttribute("movieId", movieId);
        model.addAttribute("movieTitle", movieTitle);
        model.addAttribute("price", price);
        return "rental/rent-movie";
    }

    @PostMapping("/rent")
    public String rentMovie(@RequestParam String userId, @RequestParam String movieId, 
                           @RequestParam double rentalCost, @RequestParam int rentalDays) {
        rentalService.rentMovie(userId, movieId, rentalCost, rentalDays);
        return "redirect:/rentals/my-rentals?userId=" + userId;
    }

    @PostMapping("/extend")
    public String extendRental(@RequestParam String rentalId, @RequestParam int additionalDays, 
                              @RequestParam double additionalCost, @RequestParam String userId) {
        rentalService.extendRental(rentalId, additionalDays, additionalCost);
        return "redirect:/rentals/my-rentals?userId=" + userId;
    }

    @PostMapping("/return")
    public String returnMovie(@RequestParam String rentalId, @RequestParam String userId) {
        rentalService.returnMovie(rentalId);
        return "redirect:/rentals/my-rentals?userId=" + userId;
    }

    // Admin endpoints
    @GetMapping("/admin/all")
    public String getAllRentals(Model model) {
        List<Rental> rentals = rentalService.getAllRentals();
        model.addAttribute("rentals", rentals);
        return "admin/all-rentals";
    }

    @GetMapping("/admin/user/{userId}")
    public String getUserRentals(@PathVariable String userId, Model model) {
        List<Rental> rentals = rentalService.getRentalsByUserId(userId);
        model.addAttribute("rentals", rentals);
        model.addAttribute("userId", userId);
        return "admin/user-rentals";
    }
}