package com.movieapp.servlet;

import com.movieapp.model.CardDetails;
import com.movieapp.service.CardService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/cards/*")
public class CardServlet extends HttpServlet {
    private final CardService cardService = new CardService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        List<CardDetails> cards = cardService.getCardsByUserId(userId);
        request.setAttribute("cards", cards);
        request.getRequestDispatcher("/WEB-INF/views/cards.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String action = request.getParameter("action");
        
        if ("add".equals(action)) {
            // Add a new card
            String cardNumber = request.getParameter("cardNumber");
            String cardholderName = request.getParameter("cardholderName");
            String expiryMonth = request.getParameter("expiryMonth");
            String expiryYear = request.getParameter("expiryYear");
            String cvc = request.getParameter("cvc");
            boolean isDefault = "on".equals(request.getParameter("isDefault"));
            
            CardDetails card = new CardDetails(userId, cardNumber, cardholderName, 
                                              expiryMonth, expiryYear, cvc, isDefault);
            cardService.addCard(card);
            
            response.sendRedirect(request.getContextPath() + "/cards");
        } else if ("setDefault".equals(action)) {
            // Set a card as default
            String cardNumber = request.getParameter("cardNumber");
            cardService.setDefaultCard(userId, cardNumber);
            
            response.sendRedirect(request.getContextPath() + "/cards");
        } else if ("delete".equals(action)) {
            // Delete a card
            String cardNumber = request.getParameter("cardNumber");
            cardService.deleteCard(userId, cardNumber);
            
            response.sendRedirect(request.getContextPath() + "/cards");
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
        }
    }
}