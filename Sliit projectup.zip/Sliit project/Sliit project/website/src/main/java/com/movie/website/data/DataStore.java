package com.movie.website.data;

import com.movie.website.model.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.logging.Logger;
import java.util.logging.Level;

public class DataStore implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final Logger logger = Logger.getLogger(DataStore.class.getName());
    
    private static DataStore instance;
    
    private Stack<User> users;
    private Stack<Movie> movies;
    private Stack<Rating> ratings;
    private Stack<Subscription> subscriptions;
    private Stack<Payment> payments;
    
    private DataStore() {
        users = new Stack<>();
        movies = new Stack<>();
        ratings = new Stack<>();
        subscriptions = new Stack<>();
        payments = new Stack<>();
        
        // Initialize with some data
        initializeData();
    }
    
    public static synchronized DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
        }
        return instance;
    }
    
    private void initializeData() {
        try {
            // Add admin user
            User admin = new User(UUID.randomUUID().toString(), "admin", "admin123", "admin@movies.com", true);
            users.push(admin);
            
            // Add regular user
            User user = new User(UUID.randomUUID().toString(), "user", "user123", "user@example.com", false);
            users.push(user);
            
            // Add subscriptions
            Subscription single = new Subscription(UUID.randomUUID().toString(), "Single", "For one user", 9.99, 1, 30);
            Subscription family = new Subscription(UUID.randomUUID().toString(), "Family", "For up to 4 users", 19.99, 4, 30);
            subscriptions.push(single);
            subscriptions.push(family);
            
            // Add movies
            Movie movie1 = new Movie(
                UUID.randomUUID().toString(),
                "Inception",
                "A thief who steals corporate secrets through the use of dream-sharing technology.",
                "Sci-Fi",
                "/images/inception.jpg",
                "/videos/inception.mp4",
                4.99
            );
            movie1.setNewArrival(true);
            
            Movie movie2 = new Movie(
                UUID.randomUUID().toString(),
                "The Dark Knight",
                "Batman fights the menace known as the Joker.",
                "Action",
                "/images/dark_knight.jpg",
                "/videos/dark_knight.mp4",
                3.99
            );
            movie2.setTopRated(true);
            
            Movie movie3 = new Movie(
                UUID.randomUUID().toString(),
                "Stranger Things",
                "When a young boy disappears, his mother, a police chief, and his friends must confront terrifying supernatural forces.",
                "TV Series",
                "/images/stranger_things.jpg",
                "/videos/stranger_things.mp4",
                5.99
            );
            movie3.setTvSeries(true);
            
            movies.push(movie1);
            movies.push(movie2);
            movies.push(movie3);
            
            // Add some ratings
            Rating rating1 = new Rating(UUID.randomUUID().toString(), user.getId(), movie1.getId(), 5, "Amazing movie!");
            Rating rating2 = new Rating(UUID.randomUUID().toString(), user.getId(), movie2.getId(), 5, "Best superhero movie ever!");
            
            ratings.push(rating1);
            ratings.push(rating2);
            
            // Update movie ratings
            movie1.addRating(rating1);
            movie2.addRating(rating2);
            
            logger.info("DataStore initialized successfully with sample data");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error initializing DataStore", e);
        }
    }
    
    // User methods
    public synchronized void addUser(User user) {
        if (user != null) {
            users.push(user);
            logger.info("Added new user: " + user.getUsername());
        } else {
            logger.warning("Attempted to add null user");
        }
    }
    
    public synchronized List<User> getAllUsers() {
        return users.getAllElements();
    }
    
    public synchronized User getUserById(String id) {
        if (id == null) {
            logger.warning("Attempted to get user with null ID");
            return null;
        }
        
        for (User user : users.getAllElements()) {
            if (user.getId().equals(id)) {
                return user;
            }
        }
        logger.fine("User not found with ID: " + id);
        return null;
    }
    
    public synchronized User getUserByUsername(String username) {
        if (username == null) {
            logger.warning("Attempted to get user with null username");
            return null;
        }
        
        for (User user : users.getAllElements()) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        logger.fine("User not found with username: " + username);
        return null;
    }
    
    // Movie methods
    public synchronized void addMovie(Movie movie) {
        if (movie != null) {
            movies.push(movie);
            logger.info("Added new movie: " + movie.getTitle());
        } else {
            logger.warning("Attempted to add null movie");
        }
    }
    
    public synchronized List<Movie> getAllMovies() {
        return movies.getAllElements();
    }
    
    public synchronized Movie getMovieById(String id) {
        if (id == null) {
            logger.warning("Attempted to get movie with null ID");
            return null;
        }
        
        for (Movie movie : movies.getAllElements()) {
            if (movie.getId().equals(id)) {
                return movie;
            }
        }
        logger.fine("Movie not found with ID: " + id);
        return null;
    }
    
    public synchronized List<Movie> getNewArrivals() {
        return movies.getAllElements().stream()
            .filter(Movie::isNewArrival)
            .collect(Collectors.toList());
    }
    
    public synchronized List<Movie> getTopRatedMovies() {
        List<Movie> allMovies = movies.getAllElements();
        List<Movie> sortedMovies = new ArrayList<>(allMovies);
        
        // Sort by rating (descending)
        sortedMovies.sort((a, b) -> Double.compare(b.getAverageRating(), a.getAverageRating()));
        
        return sortedMovies;
    }

    public synchronized boolean deleteMovie(String id) {
        if (id == null) {
            logger.warning("Attempted to delete movie with null ID");
            return false;
        }
        
        try {
            // Find the movie to delete
            Movie movieToDelete = getMovieById(id);
            
            if (movieToDelete != null) {
                // Create a new stack and add all movies except the one to delete
                Stack<Movie> newMovies = new Stack<>();
                for (Movie movie : movies.getAllElements()) {
                    if (!movie.getId().equals(id)) {
                        newMovies.push(movie);
                    }
                }
                movies = newMovies;
                
                // Also remove all ratings for this movie
                Stack<Rating> newRatings = new Stack<>();
                for (Rating rating : ratings.getAllElements()) {
                    if (!rating.getMovieId().equals(id)) {
                        newRatings.push(rating);
                    }
                }
                ratings = newRatings;
                
                logger.info("Deleted movie: " + movieToDelete.getTitle());
                return true;
            } else {
                logger.warning("Attempted to delete non-existent movie with ID: " + id);
                return false;
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error deleting movie", e);
            return false;
        }
    }
    
    public synchronized List<Movie> getTvSeries() {
        return movies.getAllElements().stream()
            .filter(Movie::isTvSeries)
            .collect(Collectors.toList());
    }
    
    // Rating methods
    public synchronized void addRating(Rating rating) {
        if (rating != null) {
            ratings.push(rating);
            
            // Update movie rating
            Movie movie = getMovieById(rating.getMovieId());
            if (movie != null) {
                movie.addRating(rating);
                logger.info("Added rating for movie: " + movie.getTitle());
            } else {
                logger.warning("Attempted to add rating for non-existent movie: " + rating.getMovieId());
            }
        } else {
            logger.warning("Attempted to add null rating");
        }
    }
    
    public synchronized List<Rating> getRatingsByMovieId(String movieId) {
        if (movieId == null) {
            logger.warning("Attempted to get ratings with null movie ID");
            return new ArrayList<>();
        }
        
        return ratings.getAllElements().stream()
            .filter(rating -> rating.getMovieId().equals(movieId))
            .collect(Collectors.toList());
    }

    public synchronized List<Rating> getRatingsByUserId(String userId) {
        if (userId == null) {
            logger.warning("Attempted to get ratings with null user ID");
            return new ArrayList<>();
        }
        
        return ratings.getAllElements().stream()
            .filter(rating -> rating.getUserId().equals(userId))
            .collect(Collectors.toList());
    }
    
    // Subscription methods
    public synchronized void addSubscription(Subscription subscription) {
        if (subscription != null) {
            subscriptions.push(subscription);
            logger.info("Added new subscription: " + subscription.getName());
        } else {
            logger.warning("Attempted to add null subscription");
        }
    }
    
    public synchronized List<Subscription> getAllSubscriptions() {
        return subscriptions.getAllElements();
    }
    
    public synchronized Subscription getSubscriptionById(String id) {
        if (id == null) {
            logger.warning("Attempted to get subscription with null ID");
            return null;
        }
        
        for (Subscription subscription : subscriptions.getAllElements()) {
            if (subscription.getId().equals(id)) {
                return subscription;
            }
        }
        logger.fine("Subscription not found with ID: " + id);
        return null;
    }
    
    public synchronized boolean deleteSubscription(String id) {
        if (id == null) {
            logger.warning("Attempted to delete subscription with null ID");
            return false;
        }
        
        try {
            // Find the subscription to delete
            Subscription subscriptionToDelete = getSubscriptionById(id);
            
            if (subscriptionToDelete != null) {
                // Create a new stack and add all subscriptions except the one to delete
                Stack<Subscription> newSubscriptions = new Stack<>();
                for (Subscription subscription : subscriptions.getAllElements()) {
                    if (!subscription.getId().equals(id)) {
                        newSubscriptions.push(subscription);
                    }
                }
                subscriptions = newSubscriptions;
                
                logger.info("Deleted subscription: " + subscriptionToDelete.getName());
                return true;
            } else {
                logger.warning("Attempted to delete non-existent subscription with ID: " + id);
                return false;
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error deleting subscription", e);
            return false;
        }
    }
    
    // Payment methods
    public synchronized void addPayment(Payment payment) {
        if (payment != null) {
            payments.push(payment);
            logger.info("Added new payment for user: " + payment.getUserId());
        } else {
            logger.warning("Attempted to add null payment");
        }
    }
    
    public synchronized List<Payment> getAllPayments() {
        return payments.getAllElements();
    }
    
    public synchronized List<Payment> getUnverifiedPayments() {
        return payments.getAllElements().stream()
            .filter(payment -> !payment.isVerified())
            .collect(Collectors.toList());
    }
    
    public synchronized Payment getPaymentById(String id) {
        if (id == null) {
            logger.warning("Attempted to get payment with null ID");
            return null;
        }
        
        for (Payment payment : payments.getAllElements()) {
            if (payment.getId().equals(id)) {
                return payment;
            }
        }
        logger.fine("Payment not found with ID: " + id);
        return null;
    }
    
    // For testing and debugging
    public synchronized void clearAllData() {
        users = new Stack<>();
        movies = new Stack<>();
        ratings = new Stack<>();
        subscriptions = new Stack<>();
        payments = new Stack<>();
        logger.warning("All data cleared from DataStore");
    }
}
